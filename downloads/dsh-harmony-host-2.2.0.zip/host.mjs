#!/usr/bin/env node
/** Pinned self-hosted distribution tooling. No publishing, model requests or service management. */
import { createHash, randomUUID } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, realpathSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const VERSION = '2.2.0';
export const DSH_VERSION = '0.2.1-rc.2';
export const REMOTE = Object.freeze({ name: '@linxin666/dsh-remote-web-ui', version: '0.4.7',
  file: 'linxin666-dsh-remote-web-ui-0.4.7.tgz', license: 'Apache-2.0',
  url: 'https://registry.npmjs.org/@linxin666/dsh-remote-web-ui/-/dsh-remote-web-ui-0.4.7.tgz',
  integrity: 'sha512-QNA2YFYb4y6myrRVIK/gppWVv+4RGW4OpgwIz7CWnjobfDrNRPaRaVb89TXAWwdoaYNeJ8UnLatf7UcuoKvtRQ==' });
export const BRIDGE = Object.freeze({ name: 'dsh-mobile-bridge', version: '0.2.12', file: 'dsh-mobile-bridge-0.2.12.tgz', license: 'SEE LICENSE IN LICENSE.txt' });
export const CONTROL = Object.freeze({ name: 'dsh-host-control', version: '0.1.0', file: 'dsh-host-control-0.1.0.tgz', license: 'SEE LICENSE IN LICENSE.txt' });
const COMPONENTS = [REMOTE, BRIDGE, CONTROL];
const HERE = path.dirname(fileURLToPath(import.meta.url));
const fail = message => { throw new Error(message); };
export function assertNodeVersion(version = process.versions.node) {
  const [major, minor] = version.split('.').map(Number);
  if (!((major === 22 && minor >= 19) || major >= 24)) fail('unsupported-node-version');
}
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export function inspectBridgeArchive(file) {
  const entries = execFileSync('tar', ['-tf', file], { encoding: 'utf8' }).trim().split('\n');
  for (const entry of entries) {
    if (!/^package\/(?:package\.json|README\.md|LICENSE\.txt|cordis\.patch\.yml|lib\/[A-Za-z0-9_./-]+\.m?js)$/.test(entry)
      || entry.split('/').includes('..')) fail('unexpected-first-party-package-member');
    const text = execFileSync('tar', ['-xOf', file, entry]).toString('utf8');
    if (/\/Users\/qudian\/|C:\/+Users\/+EDY|dsh-m[35]\.d-ruby\.com|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----|sk-[A-Za-z0-9]{24,}/i.test(text.replace(/\\/g, '/'))) fail('known-private-material-in-package');
  }
  return { memberCount: entries.length, explicitAllowlist: true, knownPrivateMarkers: false, userStateRead: false };
}
export function verifyIntegrity(bytes, integrity) {
  const [algorithm, digest] = integrity.split('-');
  if (!['sha256', 'sha512'].includes(algorithm) || createHash(algorithm).update(bytes).digest('base64') !== digest) fail('artifact-integrity-mismatch');
}
export function httpsOrigin(raw, allowLoopback = false) {
  let url; try { url = new URL(raw); } catch { fail('invalid-origin'); }
  const local = allowLoopback && url.protocol === 'http:' && url.hostname === '127.0.0.1';
  if ((!local && url.protocol !== 'https:') || url.username || url.password || url.search || url.hash || !['', '/'].includes(url.pathname)) fail('invalid-origin');
  if (!local && (!/^https:\/\/[A-Za-z0-9.-]+(?::443)?\/?$/.test(raw)
    || !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$/.test(url.hostname))) fail('unsupported-mobile-origin');
  return url.origin;
}
function profileName(value) {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(value)) fail('invalid-profile');
  return value;
}
function dshCommand(executable, args, options = {}) {
  const js = /\.[cm]?js$/i.test(executable);
  return execFileSync(js ? process.execPath : executable, js ? [executable, ...args] : args,
    { encoding: 'utf8', timeout: 300_000, ...options });
}
export function assertPinnedRuntime(executable, options = {}) {
  const version = dshCommand(executable, ['--version'], options).trim();
  if (version !== DSH_VERSION) fail('unsupported-dsh-version');
}
function bundleRoot(directory) {
  const root = realpathSync(directory);
  const manifest = JSON.parse(readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  if (manifest.schema !== 'dsh-harmony-store-host/v1' || manifest.dsh !== DSH_VERSION || manifest.version !== VERSION
    || !Array.isArray(manifest.artifacts) || manifest.artifacts.length !== COMPONENTS.length) fail('invalid-bundle-manifest');
  for (const expected of COMPONENTS) {
    const item = manifest.artifacts.find(row => row.name === expected.name && row.version === expected.version && row.file === expected.file);
    if (!item || !/^[a-f0-9]{64}$/.test(item.sha256)) fail('invalid-bundle-artifact');
    const bytes = readFileSync(path.join(root, 'artifacts', expected.file));
    if (sha256(bytes) !== item.sha256) fail('artifact-sha256-mismatch');
    if (expected.integrity) verifyIntegrity(bytes, expected.integrity);
  }
  return { root, manifest };
}
export function install({ bundle, home, profile, executable = 'dsh', cwd, environment = process.env }) {
  assertNodeVersion();
  if (typeof home !== 'string' || home.length === 0 || !path.isAbsolute(home)) fail('absolute-dsh-home-required');
  profileName(profile);
  const profileFile = path.join(home, 'profiles', profile, 'package.json');
  if (!existsSync(profileFile) && profile !== 'web') fail('new-custom-profile-has-no-web-template');
  if (existsSync(profileFile) && !JSON.parse(readFileSync(profileFile, 'utf8')).dsh?.profile?.bundles?.includes('@deepseek-ai/dsh-web-app')) fail('target-profile-missing-web-app');
  const verified = bundleRoot(bundle);
  const env = { ...environment, DSH_HOME: home };
  assertPinnedRuntime(executable, { env, cwd });
  dshCommand(executable, ['plugin', '--profile', profile, 'add', '--ignore-scripts', '--save-exact',
    '--registry=https://registry.npmjs.org', ...[REMOTE, BRIDGE].map(row => path.join(verified.root, 'artifacts', row.file))], { env, cwd, stdio: ['ignore', 'pipe', 'pipe'] });
  const manifest = JSON.parse(readFileSync(path.join(home, 'profiles', profile, 'package.json'), 'utf8'));
  for (const expected of [REMOTE, BRIDGE]) {
    const packageFile = path.join(home, 'profiles', profile, 'node_modules', ...expected.name.split('/'), 'package.json');
    const installed = JSON.parse(readFileSync(packageFile, 'utf8'));
    if (installed.name !== expected.name || installed.version !== expected.version
      || !manifest.dsh?.profile?.bundles?.includes(expected.name)) fail('installed-bundle-not-reconciled');
  }
  return { installed: true, dsh: DSH_VERSION, remote: REMOTE.version, bridge: BRIDGE.version,
    installScriptsExecuted: false, startedService: false };
}
export function configuration(origin, managementAuthFile = '') {
  const publicBaseUrl = httpsOrigin(origin);
  if (typeof managementAuthFile !== 'string' || (managementAuthFile.length > 0
    && (!path.isAbsolute(managementAuthFile) || /[\x00-\x1f\x7f]/.test(managementAuthFile)))) fail('absolute-management-auth-path-required');
  return [
    { id: 'remote-web-ui', config: { publicBaseUrl, autoTunnel: false, relay: false,
      pairingSource: 'public', requirePairingForLan: true, tokenTtlMs: 300000 } },
    { id: 'mobile-bridge', config: { codex: { enabled: false }, ...(managementAuthFile ? { managementAuthFile } : {}) } }
  ];
}
export function configure({ origin, out, managementAuthFile = '' }) {
  if (!path.isAbsolute(out)) fail('absolute-output-path-required');
  writeFileSync(out, JSON.stringify(configuration(origin, managementAuthFile), null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  return { generated: true, overwroteExisting: false, credentialsIncluded: false, serviceChanged: false };
}
function privateRead(file) {
  const info = statSync(file);
  if (!info.isFile() || info.size > 8192 || (process.platform !== 'win32' && (info.mode & 0o077))) fail('credential-file-must-be-private-and-bounded');
  return readFileSync(file, 'utf8').trim();
}
export async function doctor({ origin, cookieFile, accessFile, allowLoopback = false, fetchImpl = fetch }) {
  const base = httpsOrigin(origin, allowLoopback);
  const headers = { 'content-type': 'application/json' };
  if (cookieFile) {
    const cookie = privateRead(cookieFile);
    if (!/^dsh_pair=[A-Za-z0-9_-]{16,256}$/.test(cookie)) fail('invalid-cookie-file');
    headers.cookie = cookie;
  }
  if (accessFile) {
    const value = JSON.parse(privateRead(accessFile));
    if (!value || Object.keys(value).sort().join(',') !== 'clientId,clientSecret'
      || typeof value.clientId !== 'string' || typeof value.clientSecret !== 'string'
      || !/^[A-Za-z0-9._-]{8,256}$/.test(value.clientId ?? '')
      || !/^[\x21-\x7e]{16,512}$/.test(value.clientSecret ?? '')) fail('invalid-access-file');
    headers['CF-Access-Client-Id'] = value.clientId;
    headers['CF-Access-Client-Secret'] = value.clientSecret;
  }
  const rpcId = randomUUID();
  const response = await fetchImpl(base + '/remote/api/mobile/mobile.preferences', { method: 'POST', redirect: 'manual',
    headers, body: JSON.stringify({ rpcId, payload: {} }), signal: AbortSignal.timeout(10000) });
  const reader = response.body?.getReader(); const chunks = []; let size = 0;
  if (reader) while (true) {
    const item = await reader.read(); if (item.done) break;
    size += item.value.length;
    if (size > 65536) { await reader.cancel(); fail('doctor-response-too-large'); }
    chunks.push(item.value);
  }
  let result; try { result = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch {}
  const code = result?.result?.error?.code ?? result?.error?.code;
  const claimsSuccess = response.status === 200 && result?.type === 'server-response' && result?.result?.ok === true;
  if (claimsSuccess && !cookieFile) fail('unsafe-anonymous-mobile-api-success');
  const apiOk = claimsSuccess && result.rpcId === rpcId && result.result.value?.bridge?.plugin === 'mobile-bridge';
  return { httpStatus: response.status, mobileApiAuthenticated: apiOk, unpairedGate: response.status === 403 && code === 'unpaired',
    accessBlocked: [301, 302, 303, 307, 308, 401].includes(response.status) || code === 'access_denied',
    modelRequested: false, pairingIssued: false, deviceDeliveryConfirmed: false };
}

export async function build({ out, repo = path.resolve(HERE, '../..'), fetchImpl = fetch }) {
  assertNodeVersion();
  if (!path.isAbsolute(out) || existsSync(out)) fail('new-absolute-staging-directory-required');
  const bridgeRoot = path.join(repo, 'host/mobile-bridge');
  const pkg = JSON.parse(readFileSync(path.join(bridgeRoot, 'package.json'), 'utf8'));
  if (pkg.name !== BRIDGE.name || pkg.version !== BRIDGE.version || pkg.license !== BRIDGE.license
    || pkg.dsh?.engines?.dsh !== DSH_VERSION) fail('bridge-source-version-mismatch');
  mkdirSync(path.join(out, 'artifacts'), { recursive: true });
  const response = await fetchImpl(REMOTE.url, { redirect: 'error', signal: AbortSignal.timeout(30000) });
  if (!response.ok) fail('registry-artifact-unavailable');
  const remoteBytes = Buffer.from(await response.arrayBuffer());
  if (remoteBytes.length > 8 * 1024 * 1024) fail('registry-artifact-too-large');
  verifyIntegrity(remoteBytes, REMOTE.integrity);
  writeFileSync(path.join(out, 'artifacts', REMOTE.file), remoteBytes);
  const packed = JSON.parse(execFileSync('npm', ['pack', '--ignore-scripts', '--json', '--pack-destination', path.join(out, 'artifacts')],
    { cwd: bridgeRoot, encoding: 'utf8', timeout: 30000 }));
  if (packed.length !== 1 || packed[0].filename !== BRIDGE.file) fail('unexpected-bridge-package');
  const bridgeBytes = readFileSync(path.join(out, 'artifacts', BRIDGE.file));
  const privacyScan = inspectBridgeArchive(path.join(out, 'artifacts', BRIDGE.file));
  const controlRoot = path.join(repo, 'host/control-agent');
  const controlPkg = JSON.parse(readFileSync(path.join(controlRoot, 'package.json'), 'utf8'));
  if (['name', 'version', 'license'].some(key => controlPkg[key] !== CONTROL[key])) fail('control-source-version-mismatch');
  const { pack } = await import(pathToFileURL(path.join(controlRoot, 'pack.mjs')).href);
  const controlReport = await pack(path.join(out, 'artifacts', CONTROL.file), { source: controlRoot });
  const artifacts = [{ ...REMOTE, sha256: sha256(remoteBytes) }, { ...BRIDGE, sha256: sha256(bridgeBytes) },
    { ...CONTROL, sha256: controlReport.sha256 }];
  const manifest = { schema: 'dsh-harmony-store-host/v1', version: VERSION, dsh: DSH_VERSION, artifacts,
    pushIncluded: false, credentialsIncluded: false, privacyScan, controlPublicFiles: controlReport.files,
    controlServiceAutomaticallyInstalled: false, publicPublishingPerformed: false };
  writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  writeFileSync(path.join(out, 'host.mjs'), readFileSync(fileURLToPath(import.meta.url)));
  writeFileSync(path.join(out, 'README.md'), readFileSync(path.join(repo, 'docs/store-host/README.md')));
  writeFileSync(path.join(out, 'THIRD_PARTY_NOTICES.md'), readFileSync(path.join(repo, 'docs/store-host/THIRD_PARTY_NOTICES.md')));
  mkdirSync(path.join(out, 'licenses'));
  writeFileSync(path.join(out, 'licenses', 'DSH-REMOTE-LICENSE.txt'),
    readFileSync(path.join(bridgeRoot, 'LICENSE.txt')));
  writeFileSync(path.join(out, 'licenses', 'remote-web-ui-Apache-2.0.txt'),
    execFileSync('tar', ['-xOf', path.join(out, 'artifacts', REMOTE.file), 'package/LICENSE']));
  const archive = out + '.zip';
  if (existsSync(archive)) fail('archive-already-exists');
  execFileSync('python3', ['-c', `import pathlib,sys,zipfile
root=pathlib.Path(sys.argv[1]); output=pathlib.Path(sys.argv[2])
with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
 for file in sorted(root.rglob('*')):
  if file.is_file():
   info=zipfile.ZipInfo(str(file.relative_to(root)),date_time=(2026,11,1,0,0,0))
   info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644<<16
   bundle.writestr(info,file.read_bytes())
`, out, archive]);
  return { staged: true, artifacts: artifacts.map(({ name, version, file, sha256 }) => ({ name, version, file, sha256 })),
    manifestSha256: sha256(readFileSync(path.join(out, 'manifest.json'))), archiveSha256: sha256(readFileSync(archive)), publicPublishingPerformed: false };
}

function options(args) {
  const out = {};
  for (let i = 0; i < args.length; i += 2) {
    if (!/^--[a-z-]+$/.test(args[i]) || !args[i + 1] || Object.hasOwn(out, args[i])) fail('expected-unique-option-value');
    out[args[i]] = args[i + 1];
  }
  return out;
}
async function main() {
  assertNodeVersion();
  const [command, ...args] = process.argv.slice(2); const opts = options(args); let result;
  const allowed = { build: ['--out'], install: ['--bundle', '--home', '--profile', '--dsh'],
    configure: ['--origin', '--out', '--management-auth-file'], doctor: ['--origin', '--cookie-file', '--access-file'] };
  if (!Object.hasOwn(allowed, command) || Object.keys(opts).some(key => !allowed[command].includes(key))) fail('unknown-command-or-option');
  if (command === 'build') result = await build({ out: opts['--out'] });
  else if (command === 'install') result = install({ bundle: opts['--bundle'] ?? HERE, home: opts['--home'], profile: opts['--profile'] ?? 'web', executable: opts['--dsh'] ?? 'dsh' });
  else if (command === 'configure') result = configure({ origin: opts['--origin'], out: opts['--out'], managementAuthFile: opts['--management-auth-file'] ?? '' });
  else if (command === 'doctor') result = await doctor({ origin: opts['--origin'], cookieFile: opts['--cookie-file'], accessFile: opts['--access-file'] });
  else fail('usage: host.mjs install|configure|doctor; repository cli.mjs also supports build');
  console.log(JSON.stringify(result));
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  main().catch(error => { console.error(JSON.stringify({ ok: false, error: /^[a-z0-9: .|_-]+$/i.test(error.message) ? error.message : 'host-command-failed', valuesRedacted: true })); process.exitCode = 1; });
}
