# 组件来源与许可证

核对日期：2026-11-01。此清单描述本组合的实际交付物，不为私人源码授予新的开源许可。

| 组件 | 精确版本 | 来源和许可 | 本包处理 |
| --- | --- | --- | --- |
| DeepSeek Harness CLI | 0.2.1-rc.2 | [官方 npm 元数据](https://registry.npmjs.org/@deepseek-ai%2fdsh/0.2.1-rc.2)，MIT；源码仓库 `https://github.com/deepseek-ai/deepseek-harness` | 不复制发行方安装目录，不随本 ZIP 重打 CLI；使用目标用户已安装的精确版本 |
| @linxin666/dsh-remote-web-ui | 0.4.7 | [发布元数据](https://registry.npmjs.org/@linxin666%2fdsh-remote-web-ui/0.4.7)，Apache-2.0；仓库 `https://github.com/zhu1090093659/dsh-web` | 原始 npm tgz，SHA512 固定核验，保留原包全部文件和 LICENSE，额外附录许可证原文；未修改上游代码 |
| dsh-mobile-bridge | 0.2.11 | 本仓库第一方实现，原 package private=true，无已声明的开源许可；本次明确标为 SEE LICENSE IN LICENSE.txt | 保留 private=true；仅本地打包 staging，不 npm publish、不开放仓库。公开下载前由版权持有方确认分发条款和主体；不能向客户宣称其为 MIT/Apache |

remote-web-ui 的发布元数据列有 `@deepseek-ai/schemastery`、`clsx`、`cloudflared`、`qrcode.react`、`yaml`、`zod` 依赖，以及 React、React DOM、DSH peers。它们没有被本组合另行打进 ZIP，安装时由 npm registry 和 pnpm 获取，实际精确解析版本以目标 profile 的 lockfile 为准。本组合没有对上游 tarball 的 license、文件、source map 或依赖声明作删改。安装使用 `--ignore-scripts`，不运行 cloudflared 的下载脚本，也未捆绑其本机二进制。

mobile-bridge 运行源码在显式文件白名单内，使用 Node 标准库；没有附带 node_modules、DSH profiles、用户会话、配对 cookie、服务账号、AGC 材料或任何本机凭据文件。可选 Codex 代码随其原模块打包，但生成的公众 overlay 明确禁用它。

官方CLI的实际命令依据为该版本的 `dsh plugin --help` 和 npm `@deepseek-ai/dsh@0.2.1-rc.2` 中的 `lib/plugin.js`；源码行为参照 `apps/cli/src/plugin.ts`、`apps/cli/reference/README.md`。新版本源码只作导航，不能代替固定运行时实测。

第一方配套组件现附发行者王毅的有限免费使用许可（包内 licenses/DSH-REMOTE-LICENSE.txt），允许自有/获授权主机安装运行；这不公开App私有源码，也不改变上游MIT/Apache-2.0许可证。
