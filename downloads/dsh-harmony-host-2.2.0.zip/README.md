# DSH 鸿蒙自托管宿主组合 2.2.0

这是提供给已有自己 DeepSeek Harness 的用户的宿主插件组合。仅验证以下固定版本：Node `^22.19.0 || >=24.0.0`、DSH `0.2.1-rc.2`、`@linxin666/dsh-remote-web-ui 0.4.7`、`dsh-mobile-bridge 0.2.11`。不宣称兼容更新的 DSH，也不提供共享电脑、模型账号或模型额度。

这个压缩包当前是待发行 staging；没有发布 npm、修改公共域名或启动生产服务。发行方需在公开下载页面提供本压缩包及 manifest 的 SHA256，用户应先从可信下载页核对哈希，再执行包内脚本。内部 manifest 是完整性清单，不是发行方数字签名。

## 1. 准备

- 已有并确认 `dsh --version` 为 `0.2.1-rc.2`。缺少该版本时，官方 npm 包名为 `@deepseek-ai/dsh`，精确版本安装语法是 `npm install --global @deepseek-ai/dsh@0.2.1-rc.2`；用户自行决定是否安装或保留独立版本，脚本不会升级现有 DSH。
- `node --version` 符合上述范围，`pnpm --version` 可运行。DSH 的 plugin 命令实际转发给 pnpm，pnpm 是必需项。
- 记录自己要使用的 DSH home 和 profile。建议先使用一个独立 DSH home 的 `web` profile 完成验证，再按自己的停机计划修改常用实例；不要把新安装直接当成生产升级。
- 准备自己的固定 HTTPS 域名与反向代理或 named Tunnel，指向电脑的 loopback DSH Web 端口。手机支持 DNS HTTPS 默认443端口，不使用 HTTP、IP地址或任意路径作为 origin。电脑需要保持在线。

## 2. 安装插件

解压后在该目录执行，路径换成自己的实际绝对路径：

```sh
node host.mjs install --home /absolute/path/to/your-dsh-home --profile web
```

Windows 可使用 `D:/your-private/dsh-home`。如果 `dsh` 不在 PATH，可传 `--dsh /absolute/path/to/dsh`；也支持传已安装 CLI 的 `lib/bin.js`。脚本先拒绝不匹配的 DSH 版本、损坏的 tgz 或不符的 manifest，然后调用真实的 `dsh plugin --profile web add --ignore-scripts --save-exact ...`。不写已有 `cordis.patch.yml`，不启动或重启 DSH，不执行包安装脚本。

安装会从 npm 官方 registry 拉取插件依赖，插件本体为本包内的固定 tgz。依赖由目标 profile 的 pnpm lockfile 管理；脚本不会拿发行方的 lockfile 覆盖用户已有插件。由于跳过安装脚本，不使用插件自动下载 cloudflared 的能力。

## 3. 生成独立配置

```sh
node host.mjs configure --origin https://dsh.example.com --out /private/path/phone-host.cordis.yml
```

输出必须是新的绝对路径，已存在则拒绝覆盖。生成物只有公共域名和能力配置，不包含凭据。配置关闭自动 Tunnel、第三方稳定域名 relay 及 Codex 接入；保持 DSH 设备配对门，预览目录保持未授权状态。代码没有关闭电脑原有的 DSH 身份验证。

使用相同 DSH home 启动用户自己的实例；下面的3080可换为空闲端口：

```sh
DSH_HOME=/absolute/path/to/your-dsh-home dsh web --patch /private/path/phone-host.cordis.yml --host 127.0.0.1 --port 3080 --no-open
```

反向代理或用户自己的 named Tunnel 应指向这个 loopback 端口，并保留正确的原始 Host/转发 authority。不要用 `--trusted-host` 把公网入口加入原始 `/api` 信任围栏，也不要直接开放未认证的管理接口。本组合不配置 DNS、证书、路由器入站端口或 Cloudflare 账号。

## 4. 配对手机

1. 在电脑本地打开 DSH Web，进入“远程访问”，生成短时邀请链接。应显示刚配置的 HTTPS 域名；若仍是 LAN 地址，先检查本次启动是否使用了正确配置，不要把别的机器邀请改写成当前域名。
2. 鸿蒙 App → 添加机器 → 填写连接：输入自选名称、同一 HTTPS origin，以及电脑生成的 `/pair-accept?pair=…` 链接。
3. 普通 HTTPS 入口关闭 Access 开关；只有自己的入口确实使用 Cloudflare Access 时，才填这台手机专用的 Service Token Client ID/Secret。管理 API Token、Tunnel Token 留在电脑，不能导入手机。
4. 先解析预览并核对域名，再确认连接。有效期由电脑控制，配置期限不会延长邀请寿命。过期时回到电脑重新生成，刷新邀请后旧链接会失效。remote-web-ui 0.4.7 的同一链接在有效期内可重复登记设备，请勿把它分享给其他人；它不等于严格单次消费的邀请码。
5. 成功后在会话页选择自己的电脑。第一次实际发送任务会使用用户自己配置的模型，并可能计费；本组合的安装与 doctor 不提交模型任务。

## 5. 只读 doctor

```sh
node host.mjs doctor --origin https://dsh.example.com
```

无设备身份时预期 `unpairedGate:true`：证明已到配对门，不代表手机连通。若返回跳转/401，先修入口访问策略。若匿名成功读取手机 API，doctor 直接失败，应先停止公开该入口。

仅当用户有自己专用的诊断设备凭据时，可写入本机私有文本文件（Unix `chmod 600`），内容为 `dsh_pair=设备凭据`，然后使用 `--cookie-file /private/path/device-cookie.txt`；Access 服务凭据可通过 `--access-file /private/path/device-access.json` 提供，文件仅含 `clientId` 和 `clientSecret`。不把凭据放在命令行。`mobileApiAuthenticated:true` 只证明当前手机 API 鉴权，不证明模型调用、手机显示或网络长期稳定。Windows 用户自行限制这些文件的 ACL。

## 当前能力和边界

- 前台会话、待答/审批、历史读取及支持时的 SSE；断流时客户端轮询回退。是否可达还取决于用户自己的 HTTPS 代理和手机网络。
- 未包含后台 Push 插件或发行方私钥，不提供公共推送中继。不能把“前台可读”宣传成锁屏送达。
- Workspace preview 默认没有授权目录；需要用户明确设置其允许的项目根。不能复制发行方个人的路径或把整个家目录当默认范围。
- 不包含旧版 `dsh-secure-remote` 安全入口包：它现有固定13项 allowlist 与当前桥接的 SSE、预览及扩展方法不完全一致，尚不能宣称整套兼容。Access 如由用户的 named Tunnel/边缘策略提供，用户需独立验证；本组合不声称源站已做额外 Cloudflare JWT 验签。
- 卸载使用原 DSH 的 `dsh plugin --profile web remove dsh-mobile-bridge @linxin666/dsh-remote-web-ui`，并在下一次启动去掉独立 overlay。先按用户自己的计划停止该实例；不删除 DSH home、已有会话或设备文件。撤销手机需在电脑“远程访问”撤销设备；Access 凭据需另行撤销。

许可证、来源与分发边界见 `THIRD_PARTY_NOTICES.md`。源码仓库的私有状态不会因打包改变。
